package service;

import bean.Customer;

public interface IBankServiceProvider {
    void createAccount(Customer customer, String accType, float balance);
    void listAccounts();
    void calculateInterest();
}

