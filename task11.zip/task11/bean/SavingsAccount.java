package bean;
public class SavingsAccount extends Account {
    private float interestRate;
    public SavingsAccount(float balance, Customer customer, float interestRate) {
        super("Savings", Math.max(balance, 500), customer);
        this.interestRate = interestRate;
    }
    @Override
    public boolean withdraw(float amount) {
        if (balance - amount >= 500) {
            balance -= amount;
            return true;
        }
        return false;
    }
    public float getInterestRate() {
        return interestRate;
    }
}