package bean;
public class ZeroBalanceAccount extends Account {
    public ZeroBalanceAccount(float balance, Customer customer) {
        super("ZeroBalance", 0, customer);
    }
    @Override
    public boolean withdraw(float amount) {
        if (balance >= amount) {
            balance -= amount;
            return true;
        }
        return false;
    }
}