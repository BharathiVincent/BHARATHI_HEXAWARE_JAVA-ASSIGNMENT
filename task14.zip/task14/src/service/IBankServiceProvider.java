package service;
import bean.Account;
import bean.Customer;
import java.util.List;

public interface IBankServiceProvider {
    Account createAccount(Customer customer, long accNo, String accType, double balance);
    List<Account> listAccounts();
    Account getAccountDetails(long accountNumber);
    void calculateInterest();
}