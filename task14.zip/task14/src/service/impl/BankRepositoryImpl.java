package service.impl;

import bean.Account;
import bean.Customer;
import bean.Transaction;
import service.IBankRepository;
import utils.DBUtil;

import java.sql.*;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public  class BankRepositoryImpl implements IBankRepository {
    private Connection conn = DBUtil.getDBConn();

    @Override
    public Account createAccount(Customer customer, long accNo, String accType, double balance) {
        try {
            String sql = "INSERT INTO accounts (account_number, customer_id, account_type, balance) VALUES (?, ?, ?, ?)";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setLong(1, accNo);
            stmt.setInt(2, customer.getCustomerId());
            stmt.setString(3, accType);
            stmt.setDouble(4, balance);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return new Account(accType, balance, customer);
    }

    @Override
    public double getAccountBalance(long accountNumber) {
        try {
            String sql = "SELECT balance FROM accounts WHERE account_number=?";
            PreparedStatement stmt = conn.prepareStatement(sql);
            stmt.setLong(1, accountNumber);
            ResultSet rs = stmt.executeQuery();
            if (rs.next()) return rs.getDouble("balance");
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0.0;
    }

	@Override
	public List<Account> listAccounts() {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void calculateInterest() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public double deposit(long accountNumber, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public double withdraw(long accountNumber, double amount) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public boolean transfer(long fromAccountNumber, long toAccountNumber, double amount) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Account getAccountDetails(long accountNumber) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate) {
		// TODO Auto-generated method stub
		return null;
	}
}