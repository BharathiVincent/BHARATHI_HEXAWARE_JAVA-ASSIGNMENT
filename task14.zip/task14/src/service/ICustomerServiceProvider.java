package service;
	import bean.Account;
	import bean.Transaction;
	import java.util.Date;
	import java.util.List;

	public interface ICustomerServiceProvider {
	    double getAccountBalance(long accountNumber);
	    double deposit(long accountNumber, double amount);
	    double withdraw(long accountNumber, double amount);
	    boolean transfer(long fromAccountNumber, long toAccountNumber, double amount);
	    Account getAccountDetails(long accountNumber);
	    List<Transaction> getTransactions(long accountNumber, Date fromDate, Date toDate);
	}


