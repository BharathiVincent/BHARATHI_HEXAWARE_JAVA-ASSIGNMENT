package bean;

import java.time.LocalDateTime;

public class Transaction {
    private Account account;
    private String description;
    private LocalDateTime dateTime;
    private TransactionType transactionType;
    private double transactionAmount;

    public Transaction(Account account, String description, TransactionType transactionType, double transactionAmount) {
        this.account = account;
        this.description = description;
        this.transactionType = transactionType;
        this.transactionAmount = transactionAmount;
        this.dateTime = LocalDateTime.now(); // Captures the current date and time
    }

    // Getter for dateTime
    public LocalDateTime getDate() {
        return dateTime;
    }

    // (Optional) Setter for dateTime if required
    public void setDate(LocalDateTime dateTime) {
        this.dateTime = dateTime;
    }

    public void displayTransaction() {
        System.out.println("Transaction Details:");
        System.out.println("Account Number: " + account.getAccountNumber());
        System.out.println("Customer: " + account.getCustomer().getFirstName() + " " + account.getCustomer().getLastName());
        System.out.println("Type: " + transactionType);
        System.out.println("Amount: " + transactionAmount);
        System.out.println("Description: " + description);
        System.out.println("Date & Time: " + dateTime);
        System.out.println("Updated Balance: " + account.getAccountBalance());
    }

    public enum TransactionType {
        DEPOSIT,
        WITHDRAW,
        TRANSFER
    }
}