package bean;

public class Account {
	    protected static int lastAccNo = 1000;
	    protected int accountNumber;
	    protected String accountType;
	    protected double accountBalance;
	    protected Customer customer;

	    public Account(String accountType, double accountBalance, Customer customer) {
	        this.accountNumber = ++lastAccNo;
	        this.accountType = accountType;
	        this.accountBalance = accountBalance;
	        this.customer = customer;
	    }

	    public int getAccountNumber() { return accountNumber; }
	    public String getAccountType() { return accountType; }
	    public double getAccountBalance() { return accountBalance; }
	    public Customer getCustomer() { return customer; }

	    public void setAccountBalance(double accountBalance) {
	        this.accountBalance = accountBalance;
	    }

	    public void displayAccountInfo() {
	        System.out.println("Account Number: " + accountNumber);
	        System.out.println("Account Type: " + accountType);
	        System.out.println("Account Balance: " + accountBalance);
	        System.out.println("Customer: " + customer.getFirstName() + " " + customer.getLastName());
	    }
	}


