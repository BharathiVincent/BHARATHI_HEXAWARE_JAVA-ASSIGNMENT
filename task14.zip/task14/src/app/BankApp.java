package app;

import bean.Customer;
import service.impl.BankServiceProviderImpl;

import java.util.Scanner;

public class BankApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        BankServiceProviderImpl bankService = new BankServiceProviderImpl("Hexa Bank", "Chennai");

        while (true) {
            System.out.println("\nChoose an option:");
            System.out.println("1. Create Account");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transfer");
            System.out.println("5. Get Account Details");
            System.out.println("6. List Accounts");
            System.out.println("7. Exit");

            int choice = scanner.nextInt();
            if (choice == 7) break;
            
            switch (choice) {
                case 1:
                    System.out.print("Enter customer name: ");
                    String name = scanner.next();
                    Customer customer = new Customer(101, name, "", "email@example.com", "9876543210", "Address");
                    bankService.createAccount(customer, 1001, "Savings", 1000);
                    System.out.println("Account Created!");
                    break;
                case 2:
                    System.out.print("Enter account number: ");
                    long accNo = scanner.nextLong();
                    System.out.print("Enter amount to deposit: ");
                    double amount = scanner.nextDouble();
                    bankService.deposit(accNo, amount);
                    System.out.println("Deposit successful!");
                    break;
                default:
                    System.out.println("Invalid choice.");
            }
        }
        scanner.close();
    }
}