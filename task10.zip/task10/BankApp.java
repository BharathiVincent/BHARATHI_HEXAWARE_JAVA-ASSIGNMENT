package task1.task10;
import java.util.Random;
import java.util.Scanner;
public class BankApp {
	 public static void main(String[] args) {
	     Scanner sc = new Scanner(System.in);
	     Bank bank = new Bank();
	     while (true) {
	         System.out.println("\n--- Bank Menu ---");
	         System.out.println("1. Create Account");
	         System.out.println("2. Deposit");
	         System.out.println("3. Withdraw");
	         System.out.println("4. Get Balance");
	         System.out.println("5. Transfer");
	         System.out.println("6. Get Account Details");
	         System.out.println("7. Exit");
	         System.out.print("Choose option: ");
	         int choice = sc.nextInt();
	         switch (choice) {
	             case 1:
	                 sc.nextLine(); // clear newline
	                 System.out.print("Enter First Name: ");
	                 String fName = sc.nextLine();
	                 System.out.print("Enter Last Name: ");
	                 String lName = sc.nextLine();
	                 System.out.print("Enter Email: ");
	                 String email = sc.nextLine();
	                 System.out.print("Enter Phone Number: ");
	                 String phone = sc.nextLine();
	                 System.out.print("Enter Address: ");
	                 String address = sc.nextLine();
	                 System.out.print("Enter Account Type (Savings/Current): ");
	                 String accType = sc.nextLine();
	                 System.out.print("Enter Initial Balance: ");
	                 float balance = sc.nextFloat();
	                 try {
	                     Customer customer = new Customer(new Random().nextInt(10000), fName, lName, email, phone, address);
	                     bank.createAccount(customer, accType, balance);
	                 } catch (IllegalArgumentException e) {
	                     System.out.println("Error: " + e.getMessage());
	                 }
	                 break;
	             case 2:
	                 System.out.print("Enter Account Number: ");
	                 long depAcc = sc.nextLong();
	                 System.out.print("Enter Amount to Deposit: ");
	                 float depAmt = sc.nextFloat();
	                 bank.deposit(depAcc, depAmt);
	                 break;
	             case 3:
	                 System.out.print("Enter Account Number: ");
	                 long wdAcc = sc.nextLong();
	                 System.out.print("Enter Amount to Withdraw: ");
	                 float wdAmt = sc.nextFloat();
	                 bank.withdraw(wdAcc, wdAmt);
	                 break;
	             case 4:
	                 System.out.print("Enter Account Number: ");
	                 long balAcc = sc.nextLong();
	                 float balanceResult = bank.getAccountBalance(balAcc);
	                 if (balanceResult != -1)
	                     System.out.println("Current Balance: $" + balanceResult);
	                 break;
	             case 5:
	                 System.out.print("Enter From Account Number: ");
	                 long fromAcc = sc.nextLong();
	                 System.out.print("Enter To Account Number: ");
	                 long toAcc = sc.nextLong();
	                 System.out.print("Enter Amount to Transfer: ");
	                 float transAmt = sc.nextFloat();
	                 bank.transfer(fromAcc, toAcc, transAmt);
	                 break;
	             case 6:
	                 System.out.print("Enter Account Number: ");
	                 long detailsAcc = sc.nextLong();
	                 bank.getAccountDetails(detailsAcc);
	                 break;
	             case 7:
	                 System.out.println("Exiting...");
	                 sc.close();
	                 System.exit(0);
	             default:
	                 System.out.println("Invalid option. Try again.");
	         }
	     }
	 }
	}