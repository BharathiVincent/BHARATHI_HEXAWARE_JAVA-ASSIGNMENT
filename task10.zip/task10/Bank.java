package task1.task10;
import java.util.HashMap;
public class Bank {
    private HashMap<Long, Account> accounts = new HashMap<>();
    public void createAccount(Customer customer, String accType, float balance) {
        Account newAccount = new Account(customer, accType, balance);
        accounts.put(newAccount.getAccountNumber(), newAccount);
        System.out.println("Account created successfully. Account Number: " + newAccount.getAccountNumber());
    }
    public float getAccountBalance(long accountNumber) {
        if (accounts.containsKey(accountNumber)) {
            return accounts.get(accountNumber).getBalance();
        } else {
            System.out.println("Account not found.");
            return -1;
        }
    }
    public void deposit(long accountNumber, float amount) {
        if (accounts.containsKey(accountNumber)) {
            accounts.get(accountNumber).deposit(amount);
        } else {
            System.out.println("Account not found.");
        }
    }
    public void withdraw(long accountNumber, float amount) {
        if (accounts.containsKey(accountNumber)) {
            accounts.get(accountNumber).withdraw(amount);
        } else {
            System.out.println("Account not found.");
        }
    }
    public void transfer(long fromAccount, long toAccount, float amount) {
        if (!accounts.containsKey(fromAccount) || !accounts.containsKey(toAccount)) {
            System.out.println("One or both account numbers are invalid.");
            return;
        }
        Account sender = accounts.get(fromAccount);
        Account receiver = accounts.get(toAccount);
        if (sender.getBalance() >= amount) {
            sender.withdraw(amount);
            receiver.deposit(amount);
            System.out.println("Transfer successful.");
        } else {
            System.out.println("Insufficient balance for transfer.");
        }
    }
    public void getAccountDetails(long accountNumber) {
        if (accounts.containsKey(accountNumber)) {
            accounts.get(accountNumber).displayAccountDetails();
        } else {
            System.out.println("Account not found.");
        }
    }
}