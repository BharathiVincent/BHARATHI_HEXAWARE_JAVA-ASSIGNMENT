package task1.task10;
public class Account {
    private static long nextAccountNumber = 1001;
    private long accountNumber;
    private String accountType;
    private float balance;
    private Customer customer;
    public Account() {}
    public Account(Customer customer, String accountType, float balance) {
        this.accountNumber = nextAccountNumber++;
        this.customer = customer;
        this.accountType = accountType;
        this.balance = balance;
    }
    public long getAccountNumber() { return accountNumber; }
    public String getAccountType() { return accountType; }
    public float getBalance() { return balance; }
    public Customer getCustomer() { return customer; }
    public void deposit(float amount) {
        balance += amount;
        System.out.println("Deposit successful. Current Balance: $" + balance);
    }
    public void withdraw(float amount) {
        if (balance >= amount) {
            balance -= amount;
            System.out.println("Withdrawal successful. Current Balance: $" + balance);
        } else {
            System.out.println("Insufficient balance.");
        }
    }
    public void displayAccountDetails() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Type: " + accountType);
        System.out.println("Balance: $" + balance);
        customer.displayCustomerDetails();
    }
}