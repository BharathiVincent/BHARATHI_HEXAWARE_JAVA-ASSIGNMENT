package task1.task9;
public class SavingsAccount extends BankAccount {
    private double interestRate;
    public SavingsAccount(int accountNumber, String customerName, double balance, double interestRate) {
        super(accountNumber, customerName, balance);
        this.interestRate = interestRate;
    }
    @Override
    public void deposit(float amount) {
        balance += amount;
        System.out.println("Deposited: $" + amount);
    }
    @Override
    public void withdraw(float amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
        } else {
            System.out.println("Insufficient funds!");
        }
    }
    @Override
    public void calculateInterest() {
        double interest = (balance * interestRate) / 100;
        balance += interest;
        System.out.println("Interest added: $" + interest + " at rate " + interestRate + "%");
    }
}
