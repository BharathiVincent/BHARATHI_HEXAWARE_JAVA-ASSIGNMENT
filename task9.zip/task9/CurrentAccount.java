package task1.task9;
public class CurrentAccount extends BankAccount {
    private static final double OVERDRAFT_LIMIT = 1000.0;
    public CurrentAccount(int accountNumber, String customerName, double balance) {
        super(accountNumber, customerName, balance);
    }
    @Override
    public void deposit(float amount) {
        balance += amount;
        System.out.println("Deposited: $" + amount);
    }
    @Override
    public void withdraw(float amount) {
        if (amount <= balance + OVERDRAFT_LIMIT) {
            balance -= amount;
            System.out.println("Withdrew: $" + amount);
        } else {
            System.out.println("Withdrawal exceeds overdraft limit.");
        }
    }
    @Override
    public void calculateInterest() {
        System.out.println("No interest for Current Accounts.");
    }
}
