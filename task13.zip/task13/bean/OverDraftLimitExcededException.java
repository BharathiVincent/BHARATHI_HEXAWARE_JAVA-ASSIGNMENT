package bean;
public class OverDraftLimitExcededException extends Exception {
    public OverDraftLimitExcededException(String message) {
        super(message);
    }
}