package bean;
import service.IBankServiceProvider;
public class BankServiceProviderImpl extends CustomerServiceProviderImpl implements IBankServiceProvider {
    private String branchName = "Main Branch";
    private String branchAddress = "City Center";
    public void create_account(Customer customer, String accType, float balance) {
        switch (accType.toLowerCase()) {
            case "savings":
                accounts[index++] = new SavingsAccount(balance, customer, 0.04f);
                break;
            case "current":
                accounts[index++] = new CurrentAccount(balance, customer, 1000);
                break;
            case "zerobalance":
                accounts[index++] = new ZeroBalanceAccount(customer);
                break;
            default:
                System.out.println("Invalid account type");
        }
    }
    public void listAccounts() {
        for (Account acc : accounts) {
            if (acc != null) System.out.println(acc);
        }
    }
    public void calculateInterest() {
        for (Account acc : accounts) {
            if (acc instanceof SavingsAccount) {
                float interest = acc.getBalance() * ((SavingsAccount) acc).getInterestRate();
                acc.setBalance(acc.getBalance() + interest);
                System.out.println("Interest added to Account " + acc.getAccountNumber());
            }
        }
    }
}